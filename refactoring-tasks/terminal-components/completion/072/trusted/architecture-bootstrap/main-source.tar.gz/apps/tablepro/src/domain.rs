//! `TablePro`'s application-owned data adapter.
//!
//! The generic grid owns navigation and edit lifecycle. This module owns the
//! database-shaped rows, stable row keys, type-aware parsing, sorting, and
//! SQL preview generation. The split is deliberate: the library never knows
//! about databases, while the app never reaches into runtime internals.

use junie_tui::{
    CellDecor, CellRef, ColumnKey, EditIntent, FgStep, FieldError, GlyphRole, GridEditor,
    GridModel, ItemKey, Role, RowDecor, RowTotal, SortDir, StateFlags,
};

use crate::db::{ColType, Table, Value};
use crate::sql;

/// One row owns its identity, baseline and lifecycle through every transition.
#[derive(Clone, PartialEq)]
struct PendingRow {
    key: ItemKey,
    current: Vec<Value>,
    original: Option<Vec<Value>>,
    inserted: bool,
    deleted: bool,
}

impl core::fmt::Debug for PendingRow {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("PendingRow")
            .field("key", &self.key)
            .field("columns", &self.current.len())
            .field("has_baseline", &self.original.is_some())
            .field("inserted", &self.inserted)
            .field("deleted", &self.deleted)
            .finish()
    }
}

/// Application-owned pending edits over a rectangular result set.
#[derive(Debug, Clone, PartialEq)]
pub struct PendingEdits {
    rows: Vec<PendingRow>,
    // None means exhausted. Undo never rolls this allocator backward.
    next_key: Option<u64>,
}

impl PendingEdits {
    /// Start tracking `rows` without changing them.
    pub fn new(rows: Vec<Vec<Value>>) -> Self {
        let next_key = u64::try_from(rows.len())
            .ok()
            .and_then(|n| n.checked_add(1));
        Self {
            rows: rows
                .into_iter()
                .enumerate()
                .map(|(index, current)| PendingRow {
                    key: ItemKey::num((index as u64).saturating_add(1)),
                    current,
                    original: None,
                    inserted: false,
                    deleted: false,
                })
                .collect(),
            next_key,
        }
    }

    /// Number of rows currently held by the result.
    pub fn row_count(&self) -> usize {
        self.rows.len()
    }

    /// Read one current cell.
    pub fn value(&self, row: usize, col: usize) -> Option<&Value> {
        self.rows.get(row)?.current.get(col)
    }

    fn original_value(&self, row: usize, col: usize) -> Option<&Value> {
        let record = self.rows.get(row)?;
        record.original.as_ref().unwrap_or(&record.current).get(col)
    }

    /// Set one cell. Returns whether the value changed.
    pub fn set(&mut self, row: usize, col: usize, value: Value) -> bool {
        let Some(record) = self.rows.get_mut(row) else {
            return false;
        };
        let Some(cell) = record.current.get(col) else {
            return false;
        };
        if *cell == value {
            return false;
        }
        if !record.inserted && record.original.is_none() {
            record.original = Some(record.current.clone());
        }
        if let Some(cell) = record.current.get_mut(col) {
            *cell = value;
        }
        true
    }

    /// Add a NULL row, refusing without mutation if stable keys are exhausted.
    pub fn insert_row(&mut self, columns: usize) -> Option<usize> {
        self.insert_values(vec![Value::Null; columns])
    }

    fn insert_values(&mut self, values: Vec<Value>) -> Option<usize> {
        let key = self.next_key?;
        let row = self.rows.len();
        self.rows.push(PendingRow {
            key: ItemKey::num(key),
            current: values,
            original: None,
            inserted: true,
            deleted: false,
        });
        self.next_key = key.checked_add(1);
        Some(row)
    }

    /// Mark an existing row deleted, or remove a cancelled insertion.
    pub fn delete_row(&mut self, row: usize) -> bool {
        let Some(record) = self.rows.get_mut(row) else {
            return false;
        };
        if record.inserted {
            self.rows.remove(row);
            return true;
        }
        if record.deleted {
            return false;
        }
        record.deleted = true;
        true
    }

    fn toggle_delete(&mut self, row: usize) -> bool {
        let Some(record) = self.rows.get_mut(row) else {
            return false;
        };
        if record.inserted {
            self.rows.remove(row);
        } else {
            if !record.deleted
                && let Some(original) = record.original.take()
            {
                record.current = original;
            }
            record.deleted = !record.deleted;
        }
        true
    }

    /// Whether the row was inserted by the user.
    pub fn is_inserted(&self, row: usize) -> bool {
        self.rows.get(row).is_some_and(|record| record.inserted)
    }

    /// Whether the row was marked for deletion.
    pub fn is_deleted(&self, row: usize) -> bool {
        self.rows.get(row).is_some_and(|record| record.deleted)
    }

    /// Whether one cell differs from its original value.
    pub fn is_dirty(&self, row: usize, col: usize) -> bool {
        if self.is_inserted(row) {
            return self
                .value(row, col)
                .is_some_and(|value| *value != Value::Null);
        }
        self.value(row, col)
            .zip(self.original_value(row, col))
            .is_some_and(|(current, original)| current != original)
    }

    /// Whether any cell or row lifecycle operation is pending.
    pub fn is_dirty_row(&self, row: usize) -> bool {
        self.is_inserted(row)
            || self.is_deleted(row)
            || (0..self.current_row_width(row)).any(|col| self.is_dirty(row, col))
    }

    /// Number of changed cells, excluding row lifecycle markers.
    pub fn dirty_cell_count(&self) -> usize {
        (0..self.row_count())
            .map(|row| {
                (0..self.current_row_width(row))
                    .filter(|&col| self.is_dirty(row, col))
                    .count()
            })
            .sum()
    }

    /// Row indexes with pending cell or row changes.
    pub fn dirty_rows(&self) -> Vec<usize> {
        (0..self.row_count())
            .filter(|&row| self.is_dirty_row(row))
            .collect()
    }

    /// Discard pending edits and restore the loaded clean rows.
    pub fn clear(&mut self) {
        self.rows.retain(|record| !record.inserted);
        for record in &mut self.rows {
            if let Some(original) = record.original.take() {
                record.current = original;
            }
            record.deleted = false;
        }
    }

    /// Reorder whole records; invalid permutations leave the result unchanged.
    pub fn reorder(&mut self, order: &[usize]) {
        let mut seen = vec![false; self.rows.len()];
        if order.len() != self.rows.len()
            || order.iter().any(|&index| {
                let Some(slot) = seen.get_mut(index) else {
                    return true;
                };
                core::mem::replace(slot, true)
            })
        {
            return;
        }
        let mut records: Vec<_> = core::mem::take(&mut self.rows)
            .into_iter()
            .map(Some)
            .collect();
        self.rows = order
            .iter()
            .filter_map(|&index| records.get_mut(index).and_then(Option::take))
            .collect();
    }
}

/// Quote a database value for the deterministic SQL preview.
pub(crate) fn sql_literal(value: &Value) -> String {
    match value {
        Value::Null => "NULL".to_owned(),
        Value::Default => "DEFAULT".to_owned(),
        Value::Text(text) => format!("'{}'", text.replace('\'', "''")),
        Value::Int(value) => value.to_string(),
        Value::Num(value) => format!("{value:.2}"),
        Value::Bool(value) => value.to_string(),
        Value::Json(value) => format!("'{}'::jsonb", value.replace('\'', "''")),
    }
}

/// Build the statements `TablePro` would send for pending result edits.
pub(crate) fn preview_sql(
    table: &Table,
    columns: &[(String, ColType)],
    pending: &PendingEdits,
) -> Vec<String> {
    let pk = table.primary_key();
    let where_clause = |row: usize| {
        let mut terms = Vec::new();
        if pk.is_empty() {
            for (col, _) in columns.iter().enumerate() {
                let Some((name, _)) = columns.get(col) else {
                    continue;
                };
                let value = pending.original_value(row, col).unwrap_or(&Value::Null);
                terms.push(match value {
                    Value::Null => format!("{name} IS NULL"),
                    value => format!("{name} = {}", sql_literal(value)),
                });
            }
        } else {
            for key in &pk {
                let Some(col) = columns.iter().position(|(name, _)| name == &key.name) else {
                    continue;
                };
                let value = pending.original_value(row, col).unwrap_or(&Value::Null);
                terms.push(format!("{} = {}", key.name, sql_literal(value)));
            }
        }
        if terms.is_empty() {
            "1 = 0".to_owned()
        } else {
            terms.join(" AND ")
        }
    };

    let dirty_rows = pending.dirty_rows();
    let mut out = Vec::new();

    // Keep the save order deterministic and compatible with TablePro's old
    // commit queue: updates, then inserts, then deletes.
    for &row in &dirty_rows {
        if pending.is_inserted(row) || pending.is_deleted(row) {
            continue;
        }
        let mut sets = Vec::new();
        for col in 0..pending.current_row_width(row) {
            if pending.is_dirty(row, col)
                && let Some((name, _)) = columns.get(col)
                && let Some(value) = pending.value(row, col)
            {
                sets.push(format!("{name} = {}", sql_literal(value)));
            }
        }
        if !sets.is_empty() {
            out.push(format!(
                "UPDATE {} SET {} WHERE {};",
                table.qualified(),
                sets.join(", "),
                where_clause(row)
            ));
        }
    }

    for &row in &dirty_rows {
        if pending.is_inserted(row) && !pending.is_deleted(row) {
            let mut names = Vec::new();
            let mut values = Vec::new();
            for (col, (name, _)) in columns.iter().enumerate() {
                let value = pending.value(row, col).unwrap_or(&Value::Null);
                if !matches!(value, Value::Default) {
                    names.push(name.clone());
                    values.push(sql_literal(value));
                }
            }
            if names.is_empty() {
                out.push(format!("INSERT INTO {} DEFAULT VALUES;", table.qualified()));
            } else {
                out.push(format!(
                    "INSERT INTO {} ({}) VALUES ({});",
                    table.qualified(),
                    names.join(", "),
                    values.join(", ")
                ));
            }
        }
    }

    for &row in &dirty_rows {
        if pending.is_deleted(row) && !pending.is_inserted(row) {
            out.push(format!(
                "DELETE FROM {} WHERE {};",
                table.qualified(),
                where_clause(row)
            ));
        }
    }
    out
}

impl PendingEdits {
    fn current_row_width(&self, row: usize) -> usize {
        self.rows.get(row).map_or(0, |record| record.current.len())
    }
}

/// A database result adapted to the generic keyed grid.
#[derive(Clone, PartialEq)]
pub struct ResultGrid {
    types: Vec<ColType>,
    pending: PendingEdits,
    sort: Option<(ColumnKey, SortDir)>,
    total: usize,
    editable: bool,
    source: Option<String>,
    read_only_reason: Option<String>,
    // Text and JSON cells borrow their already-owned value at read time;
    // only scalar values that need formatting allocate a cached string.
    display: Vec<Option<String>>,
    undo: Vec<PendingEdits>,
}

impl core::fmt::Debug for ResultGrid {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("ResultGrid")
            .field("types", &self.types)
            .field("rows", &self.row_count())
            .field("pending_operations", &self.pending_total())
            .field("total", &self.total)
            .field("editable", &self.editable)
            .field("has_source", &self.source.is_some())
            .field("has_read_only_reason", &self.read_only_reason.is_some())
            .field("undo_depth", &self.undo.len())
            .field("sort", &self.sort)
            .finish_non_exhaustive()
    }
}

impl ResultGrid {
    /// An empty, read-only result adapter.
    pub fn empty() -> Self {
        Self::from_result(&sql::ResultSet {
            columns: Vec::new(),
            rows: Vec::new(),
            total: 0,
            source: None,
            duration_ms: 0,
            editable: false,
        })
    }

    /// Adapt one SQL result without exposing database types to `junie-tui`.
    pub fn from_result(result: &sql::ResultSet) -> Self {
        let pending = PendingEdits::new(result.rows.clone());
        let read_only_reason = (!result.editable)
            .then(|| "Read-only result: select a primary-key column to edit".to_owned());
        let mut grid = Self {
            types: result.columns.iter().map(|(_, ty)| *ty).collect(),
            pending,
            sort: None,
            total: result.total,
            editable: result.editable,
            source: result.source.clone(),
            read_only_reason,
            display: Vec::new(),
            undo: Vec::new(),
        };
        grid.rebuild_display();
        grid
    }

    /// Number of loaded rows.
    pub fn row_count(&self) -> usize {
        self.pending.row_count()
    }

    /// Total rows represented by the query, including rows beyond the cap.
    pub fn total(&self) -> usize {
        self.total.max(self.row_count())
    }

    /// Whether cells may be edited through `Grid::update_editable`.
    pub fn is_editable(&self) -> bool {
        self.editable
    }

    /// The source relation, when the result came from one table.
    pub fn source(&self) -> Option<&str> {
        self.source.as_deref()
    }

    /// Current pending-edit state.
    pub fn pending(&self) -> &PendingEdits {
        &self.pending
    }

    /// Number of pending row updates, inserts and deletes.
    /// Multiple changed cells in one existing row form one update.
    pub fn pending_total(&self) -> usize {
        self.pending
            .rows
            .iter()
            .enumerate()
            .map(|(row, cells)| {
                if self.pending.is_inserted(row) {
                    1
                } else {
                    usize::from(self.pending.is_deleted(row)).saturating_add(usize::from(
                        (0..cells.current.len()).any(|col| self.pending.is_dirty(row, col)),
                    ))
                }
            })
            .sum()
    }

    /// Insert a row with typed NULL/default values.
    pub fn insert_row(&mut self) -> Option<usize> {
        if !self.editable {
            return None;
        }
        let before = self.pending.clone();
        let row = self.pending.insert_row(self.types.len())?;
        self.undo.push(before);
        self.rebuild_display();
        Some(row)
    }

    /// Insert schema-derived DEFAULT/NULL values as one undoable operation.
    pub(crate) fn insert_row_with_defaults(&mut self, defaults: &[bool]) -> Option<usize> {
        if !self.editable || defaults.len() != self.types.len() {
            return None;
        }
        let before = self.pending.clone();
        let values = defaults
            .iter()
            .map(|default| {
                if *default {
                    Value::Default
                } else {
                    Value::Null
                }
            })
            .collect();
        let row = self.pending.insert_values(values)?;
        self.undo.push(before);
        self.rebuild_display();
        Some(row)
    }

    /// Toggle a row deletion; marking deletion replaces existing cell updates.
    pub fn toggle_delete(&mut self, row: usize) -> bool {
        if !self.editable {
            return false;
        }
        let before = self.pending.clone();
        if !self.pending.toggle_delete(row) {
            return false;
        }
        self.undo.push(before);
        self.rebuild_display();
        true
    }

    /// Mark a row deleted, preserving it for undo/save preview.
    pub fn delete_row(&mut self, row: usize) -> bool {
        if !self.editable {
            return false;
        }
        let before = self.pending.clone();
        let changed = self.pending.delete_row(row);
        if changed {
            self.undo.push(before);
            self.rebuild_display();
        }
        changed
    }

    /// Restore all cells and row lifecycle markers to the clean baseline.
    pub fn discard(&mut self) {
        self.undo.push(self.pending.clone());
        self.pending.clear();
        self.restore_sort();
    }

    /// Restore the previous pending state, if one exists.
    pub fn undo(&mut self) -> bool {
        let Some(previous) = self.undo.pop() else {
            return false;
        };
        let next_key = self
            .pending
            .next_key
            .zip(previous.next_key)
            .map(|(a, b)| a.max(b));
        self.pending = previous;
        self.pending.next_key = next_key;
        self.restore_sort();
        true
    }

    /// Expose a deterministic position label for app status bars.
    pub fn position_label(&self, first_row: usize, visible_rows: usize) -> String {
        if self.row_count() == 0 {
            return "0 rows".to_owned();
        }
        let first = first_row.saturating_add(1).min(self.row_count());
        let last = first
            .saturating_add(visible_rows.saturating_sub(1))
            .min(self.row_count());
        format!("rows {first}–{last} of {}", self.total())
    }

    /// Number of changed cells.
    pub fn dirty_cell_count(&self) -> usize {
        self.pending.dirty_cell_count()
    }

    /// Sort by a grid column key, retaining keyed row identity and edits.
    pub fn sort(&mut self, key: ColumnKey, direction: SortDir) {
        let Some(column) = usize::from(key.raw()).checked_sub(1) else {
            return;
        };
        if column >= self.types.len() {
            return;
        }
        self.sort = Some((key, direction));
        let mut order: Vec<usize> = (0..self.row_count()).collect();
        order.sort_by(|&a, &b| {
            let left = self.pending.value(a, column).unwrap_or(&Value::Null);
            let right = self.pending.value(b, column).unwrap_or(&Value::Null);
            let cmp = sql::cmp_values(left, right);
            if direction == SortDir::Asc {
                cmp
            } else {
                cmp.reverse()
            }
        });
        self.pending.reorder(&order);
        self.rebuild_display();
    }

    fn restore_sort(&mut self) {
        if let Some((key, direction)) = self.sort {
            self.sort(key, direction);
        } else {
            self.rebuild_display();
        }
    }

    fn rebuild_display(&mut self) {
        self.display = self
            .pending
            .rows
            .iter()
            .flat_map(|row| {
                row.current.iter().map(|value| match value {
                    Value::Text(_) | Value::Json(_) => None,
                    value => Some(value.display()),
                })
            })
            .collect();
    }

    fn display_cell(&self, row: usize, col: usize) -> Option<&str> {
        match self.pending.value(row, col)? {
            Value::Text(value) | Value::Json(value) => Some(value.as_str()),
            _ => self
                .types
                .len()
                .checked_mul(row)
                .and_then(|offset| offset.checked_add(col))
                .and_then(|index| self.display.get(index))
                .and_then(Option::as_deref),
        }
    }

    fn parse_value(&self, col: usize, text: &str) -> Result<Value, FieldError> {
        let Some(ty) = self.types.get(col).copied() else {
            return Err(FieldError::coded("Unknown result column", "column"));
        };
        if text.trim().eq_ignore_ascii_case("NULL") {
            return Ok(Value::Null);
        }
        match ty {
            ColType::Int => text
                .trim()
                .parse::<i64>()
                .map(Value::Int)
                .map_err(|_| FieldError::coded("Enter a whole number", "integer")),
            ColType::Numeric => text
                .trim()
                .parse::<f64>()
                .ok()
                .filter(|value| value.is_finite())
                .map(Value::Num)
                .ok_or_else(|| FieldError::coded("Enter a finite number", "numeric")),
            ColType::Bool => match text.trim().to_ascii_lowercase().as_str() {
                "true" | "t" | "1" => Ok(Value::Bool(true)),
                "false" | "f" | "0" => Ok(Value::Bool(false)),
                _ => Err(FieldError::coded("Enter true or false", "boolean")),
            },
            ColType::Json => Ok(Value::Json(text.to_owned())),
            ColType::Uuid | ColType::Text | ColType::Timestamp | ColType::Date | ColType::Enum => {
                Ok(Value::Text(text.to_owned()))
            }
        }
    }
}

impl GridModel for ResultGrid {
    fn row_count(&self) -> usize {
        self.row_count()
    }

    fn row_key(&self, row: usize) -> ItemKey {
        self.pending
            .rows
            .get(row)
            .map_or_else(|| ItemKey::index(row), |record| record.key)
    }

    fn cell(&self, row: usize, col: usize) -> Option<CellRef<'_>> {
        self.display_cell(row, col).map(CellRef::new)
    }

    fn row_decor(&self, row: usize) -> RowDecor<'_> {
        RowDecor {
            marker: if self.pending.is_deleted(row) {
                Some(GlyphRole::Deleted)
            } else if self.pending.is_inserted(row) {
                Some(GlyphRole::Inserted)
            } else {
                None
            },
            strike: self.pending.is_deleted(row),
            tone: self
                .pending
                .is_deleted(row)
                .then_some(Role::Fg(FgStep::Faint)),
            flags: if self.pending.is_dirty_row(row) {
                StateFlags::DIRTY
            } else {
                StateFlags::empty()
            },
            ..RowDecor::default()
        }
    }

    fn cell_decor(&self, row: usize, col: usize) -> CellDecor<'_> {
        CellDecor {
            dirty: self.pending.is_dirty(row, col),
            ..CellDecor::default()
        }
    }

    fn total(&self) -> RowTotal {
        RowTotal::Exact(self.total())
    }

    fn read_only_reason(&self) -> Option<&str> {
        self.read_only_reason.as_deref()
    }
}

impl GridEditor for ResultGrid {
    fn edit_intent(&self, row: usize, col: usize) -> EditIntent<'_> {
        if !self.editable || self.pending.is_deleted(row) || self.pending.value(row, col).is_none()
        {
            return EditIntent::Refuse {
                reason: self
                    .read_only_reason
                    .as_deref()
                    .unwrap_or("Cell is read-only"),
            };
        }
        self.display_cell(row, col).map_or(
            EditIntent::Refuse {
                reason: "Missing cell",
            },
            |initial| EditIntent::Inline { initial },
        )
    }

    fn apply_cycle(&mut self, row: usize, col: usize) {
        if !self.editable
            || self.pending.is_deleted(row)
            || self.pending.value(row, col).is_none()
            || self.types.get(col) != Some(&ColType::Bool)
        {
            return;
        }
        let next = match self.pending.value(row, col) {
            Some(Value::Bool(true)) => Value::Bool(false),
            Some(Value::Bool(false)) => Value::Null,
            _ => Value::Bool(true),
        };
        let before = self.pending.clone();
        if self.pending.set(row, col, next) {
            self.undo.push(before);
            self.rebuild_display();
        }
    }

    fn commit_cell(&mut self, row: usize, col: usize, text: &str) -> Result<(), FieldError> {
        let value = self.parse_value(col, text)?;
        let before = self.pending.clone();
        if !self.pending.set(row, col, value) {
            return Ok(());
        }
        self.undo.push(before);
        self.rebuild_display();
        Ok(())
    }

    fn is_editable(&self, row: usize, col: usize) -> bool {
        self.editable && !self.pending.is_deleted(row) && self.pending.value(row, col).is_some()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exhausted_insert_is_atomic_and_undo_never_reuses_keys() {
        let mut grid = ResultGrid::empty();
        grid.editable = true;
        grid.pending.next_key = Some(u64::MAX);
        let Some(row) = grid.insert_row() else {
            unreachable!("last key");
        };
        assert_eq!(grid.row_key(row), ItemKey::num(u64::MAX));
        assert!(grid.undo());
        let before = grid.clone();
        assert_eq!(grid.insert_row(), None);
        assert_eq!(grid, before);
    }

    #[test]
    fn sorted_insert_update_delete_sql_uses_each_records_original_key() {
        let mut pending = PendingEdits::new(vec![
            vec![Value::Int(7), Value::Text("old".into())],
            vec![Value::Int(9), Value::Text("other".into())],
        ]);
        let Some(inserted) = pending.insert_row(2) else {
            unreachable!("key");
        };
        assert!(pending.set(inserted, 0, Value::Int(1)));
        pending.reorder(&[2, 1, 0]);
        assert!(pending.set(2, 0, Value::Int(8)));
        assert!(pending.delete_row(1));
        assert_eq!(
            preview_sql(&CatalogTable::orders(), &columns(), &pending),
            vec![
                "UPDATE public.orders SET id = 8 WHERE id = 7;",
                "INSERT INTO public.orders (id, name) VALUES (1, NULL);",
                "DELETE FROM public.orders WHERE id = 9;",
            ]
        );
        pending.clear();
        assert_eq!(pending.value(0, 0), Some(&Value::Int(9)));
        assert_eq!(pending.value(1, 0), Some(&Value::Int(7)));
        assert!(pending.dirty_rows().is_empty());
    }

    #[test]
    fn inserted_default_is_distinct_from_explicit_null_in_preview() {
        let mut grid = ResultGrid::from_result(&sql::ResultSet {
            columns: columns(),
            rows: Vec::new(),
            total: 0,
            source: Some("public.orders".to_owned()),
            duration_ms: 0,
            editable: true,
        });
        let before = grid.clone();
        assert!(grid.insert_row_with_defaults(&[true]).is_none());
        assert_eq!(grid, before);
        let Some(row) = grid.insert_row_with_defaults(&[true, false]) else {
            unreachable!("insert")
        };
        assert_eq!(grid.pending().value(row, 0), Some(&Value::Default));
        assert_eq!(grid.pending().value(row, 1), Some(&Value::Null));
        assert_eq!(
            preview_sql(&CatalogTable::orders(), &columns(), grid.pending()),
            vec!["INSERT INTO public.orders (name) VALUES (NULL);"]
        );
        assert!(grid.undo());
        assert!(grid.insert_row_with_defaults(&[true, true]).is_some());
        assert_eq!(
            preview_sql(&CatalogTable::orders(), &columns(), grid.pending()),
            vec!["INSERT INTO public.orders DEFAULT VALUES;"]
        );
    }

    #[test]
    fn delete_toggle_replaces_updates_and_undo_restores_full_row_snapshot() {
        let mut grid = ResultGrid::from_result(&sql::ResultSet {
            columns: columns(),
            rows: vec![vec![Value::Int(7), Value::Text("old".to_owned())]],
            total: 1,
            source: Some("public.orders".to_owned()),
            duration_ms: 0,
            editable: true,
        });
        let key = grid.row_key(0);
        assert!(grid.commit_cell(0, 1, "edited").is_ok());
        assert!(grid.toggle_delete(0));
        assert_eq!(grid.pending_total(), 1);
        assert_eq!(
            grid.pending().value(0, 1),
            Some(&Value::Text("old".to_owned()))
        );
        assert!(grid.undo());
        assert_eq!(grid.row_key(0), key);
        assert_eq!(
            grid.pending().value(0, 1),
            Some(&Value::Text("edited".to_owned()))
        );
        assert!(!grid.pending().is_deleted(0));
        assert!(grid.toggle_delete(0));
        assert!(grid.toggle_delete(0));
        assert_eq!(grid.pending_total(), 0);
        assert_eq!(grid.row_key(0), key);
    }

    fn columns() -> Vec<(String, ColType)> {
        vec![
            ("id".to_owned(), ColType::Int),
            ("name".to_owned(), ColType::Text),
        ]
    }

    // Restores 794b095 model::tests::preview_sql_orders_updates_inserts_deletes:
    // reverting one update preserves the independent deletion and its SQL.
    #[test]
    fn preview_sql_orders_updates_inserts_deletes() -> Result<(), String> {
        let catalog = crate::db::Catalog::acme_prod();
        let table = catalog.find(None, "orders").ok_or("orders missing")?;
        let columns = table
            .columns
            .iter()
            .map(|column| (column.name.clone(), column.ty))
            .collect::<Vec<_>>();
        let mut pending = PendingEdits::new(crate::db::rows(table, 0, 3));
        let status = columns
            .iter()
            .position(|(name, _)| name == "status")
            .ok_or("status missing")?;
        let original = pending
            .value(1, status)
            .cloned()
            .ok_or("original status missing")?;
        assert!(pending.set(1, status, Value::Text("shipped".to_owned())));
        assert!(pending.delete_row(2));
        let sql = preview_sql(table, &columns, &pending);
        assert_eq!(sql.len(), 2);
        assert!(sql.first().is_some_and(|statement| {
            statement.starts_with("UPDATE public.orders SET status = 'shipped' WHERE id = '")
        }));
        assert!(sql.get(1).is_some_and(|statement| {
            statement.starts_with("DELETE FROM public.orders WHERE id = '")
        }));
        assert!(pending.set(1, status, original));
        let reverted = preview_sql(table, &columns, &pending);
        assert_eq!(reverted.len(), 1);
        assert_eq!(reverted.first(), sql.get(1));
        Ok(())
    }

    #[test]
    fn pending_update_uses_original_key_and_escapes_text() {
        let table = CatalogTable::orders();
        let mut pending = PendingEdits::new(vec![vec![
            Value::Int(7),
            Value::Text("O'Reilly".to_owned()),
        ]]);
        assert!(pending.set(0, 1, Value::Text("new value".to_owned())));
        let sql = preview_sql(&table, &columns(), &pending);
        assert_eq!(
            sql,
            vec!["UPDATE public.orders SET name = 'new value' WHERE id = 7;".to_owned()]
        );
    }

    #[test]
    fn grid_adapter_marks_dirty_cells_and_parses_typed_edits() {
        let result = sql::ResultSet {
            columns: columns(),
            rows: vec![vec![Value::Int(1), Value::Text("Ada".to_owned())]],
            total: 1,
            source: Some("public.orders".to_owned()),
            duration_ms: 1,
            editable: true,
        };
        let mut grid = ResultGrid::from_result(&result);
        assert_eq!(grid.row_key(0), ItemKey::num(1));
        assert!(grid.commit_cell(0, 0, "2").is_ok());
        assert!(grid.pending().is_dirty(0, 0));
        assert_eq!(grid.cell(0, 0).map(|cell| cell.text), Some("2"));
        assert!(grid.commit_cell(0, 0, "not an int").is_err());
        assert_eq!(grid.cell(0, 0).map(|cell| cell.text), Some("2"));
    }

    #[test]
    fn sort_preserves_logical_row_keys() {
        let result = sql::ResultSet {
            columns: vec![("id".to_owned(), ColType::Int)],
            rows: vec![vec![Value::Int(20)], vec![Value::Int(10)]],
            total: 2,
            source: None,
            duration_ms: 1,
            editable: false,
        };
        let mut grid = ResultGrid::from_result(&result);
        let first_key = grid.row_key(0);
        grid.sort(ColumnKey::num(1), SortDir::Asc);
        assert_eq!(grid.cell(0, 0).map(|cell| cell.text), Some("10"));
        assert_eq!(grid.row_key(1), first_key);
    }

    struct CatalogTable;

    impl CatalogTable {
        fn orders() -> Table {
            crate::db::Catalog::acme_prod()
                .find(Some("public"), "orders")
                .cloned()
                .unwrap_or_else(|| Table {
                    schema: "public".to_owned(),
                    name: "orders".to_owned(),
                    kind: crate::db::ObjectKind::Table,
                    columns: vec![crate::db::Column {
                        name: "id".to_owned(),
                        ty: ColType::Int,
                        nullable: false,
                        default: None,
                        primary: true,
                        references: None,
                        enum_values: Vec::new(),
                        generated: false,
                    }],
                    indexes: Vec::new(),
                    constraints: Vec::new(),
                    triggers: Vec::new(),
                    row_count: 1,
                    comment: None,
                })
        }
    }
}
