//! Pinned 794b095 fixture graph, migrated as domain data only.
//! Canonical role keys replace the source fixture's short references together;
//! daemon services and virtual time remain the current safe simulation.
use crate::domain::account::{
    Account, AccountId, AccountIdentity, AccountRegistry, Confidence, CredentialSource,
    DetectedKind, IdentitySubject, IssueCode, Lifecycle, Recoverability, RecoverableIssue,
    ValidationLevel, ValidationState,
};
use crate::domain::agent::{Agent, Provider};
use crate::domain::instance::{
    DaemonSnapshot, Instance, InstanceStatus, ManifestError, RunId, SessionRecord, SessionStatus,
};
use crate::domain::onepassword::OpReference;
use crate::domain::usage::{
    AccountUsage, FreshnessInfo, QuotaStatus, QuotaWindow, WindowCategory, WindowUnit,
};
use crate::domain::workspace::{
    AllowedRoles, EnvVar, Isolation, Mount, RoleEntry, RolePolicy, RoleSource, Workspace,
};
use crate::scenario::Scenario;
use crate::sim::pty::{Daemon, Span, SplitDir, TextViewport, Tone};
use crate::sim::world::{GithubRepo, World};

fn op_ref(account: &str, vault: (&str, &str), item: (&str, &str), field: &str) -> OpReference {
    OpReference {
        account: account.into(),
        vault_id: vault.0.into(),
        vault_name: vault.1.into(),
        item_id: item.0.into(),
        item_title: item.1.into(),
        section: None,
        field_id: field.into(),
        field_label: field.into(),
    }
}

fn handle(s: &str) -> Option<IdentitySubject> {
    Some(IdentitySubject::Handle(s.into()))
}

pub(crate) fn roles() -> Vec<RoleEntry> {
    let git = |name: &str, desc: &str, trusted: bool| RoleEntry {
        namespace: "chainargos".into(),
        name: name.into(),
        source: RoleSource::Git {
            url: "github.com/chainargos/roles".into(),
            branch: "main".into(),
        },
        trusted,
        in_registry: true,
        description: desc.into(),
        load_error: None,
    };
    vec![
        git(
            "the-architect",
            "Full-stack design and refactoring; Claude Code default",
            true,
        ),
        git("backend", "Rust and Postgres services", true),
        git(
            "reviewer",
            "Read-mostly code review with limited write scope",
            true,
        ),
        git("sre", "Infrastructure, Terraform, Kubernetes", true),
        RoleEntry {
            namespace: "acme-labs".into(),
            name: "data-eng".into(),
            source: RoleSource::Git {
                url: "github.com/acme-labs/roles-experimental".into(),
                branch: "next".into(),
            },
            trusted: false,
            in_registry: true,
            description: "Notebook and pipeline tooling (untrusted source)".into(),
            load_error: Some("trust required".into()),
        },
        RoleEntry {
            namespace: "local".into(),
            name: "writer".into(),
            source: RoleSource::Local {
                path: "~/roles/writer".into(),
            },
            trusted: true,
            in_registry: false,
            description: "Docs and release notes".into(),
            load_error: None,
        },
    ]
}

/// A large, deterministic Role registry (`svc-001` …) so the scoped-config
/// screens prove they scale: every Role is trusted, in the registry, and
/// carries no configuration until an operator adds some.
fn generated_roles(n: usize) -> Vec<RoleEntry> {
    const AREAS: [&str; 6] = ["billing", "ledger", "search", "notify", "ingest", "auth"];
    (1..=n)
        .zip(AREAS.iter().cycle().skip(1))
        .map(|(i, area)| RoleEntry {
            namespace: "chainargos".into(),
            name: format!("svc-{i:03}"),
            source: RoleSource::Git {
                url: "github.com/chainargos/roles".into(),
                branch: "main".into(),
            },
            trusted: true,
            in_registry: true,
            description: format!("{area} service agent #{i}"),
            load_error: None,
        })
        .collect()
}

fn workspaces(rich: bool) -> Vec<Workspace> {
    let mut v = vec![];
    let mut w = Workspace::new(1, "payments-platform", "/workspace/payments-platform");
    w.mounts = vec![
        Mount::host("~/src/payments-platform", "/workspace/payments-platform")
            .repository()
            .isolation(Isolation::Worktree),
        Mount::host("~/src/shared-libs", "/workspace/libs").readonly(true),
    ];
    w.roles = RolePolicy {
        allowed: AllowedRoles::Custom(vec![
            "the-architect".into(),
            "backend".into(),
            "reviewer".into(),
        ]),
        default: Some("the-architect".into()),
        last: Some("the-architect".into()),
    };
    w.env = vec![
        EnvVar::plain(
            "DATABASE_URL",
            "postgres://payments:pw-fixture-only@db.internal:5432/payments",
        ),
        EnvVar::op(
            "STRIPE_KEY",
            op_ref(
                "chainargos.1password.com",
                ("v_eng01", "Engineering"),
                ("it_str01", "Stripe · sandbox"),
                "credential",
            ),
        ),
        EnvVar::plain("LOG_LEVEL", "debug"),
        EnvVar::host("GH_TOKEN", "GH_TOKEN"),
    ];
    w.role_env.insert(
        "backend".into(),
        vec![EnvVar::op(
            "OPENAI_API_KEY",
            op_ref(
                "chainargos.1password.com",
                ("v_eng01", "Engineering"),
                ("it_cdx01", "OpenAI · Codex Primary"),
                "credential",
            ),
        )],
    );
    // two Anthropic accounts at once: Personal is the inherited registry
    // default, Work is switched on here; Codex Primary is inherited
    w.accounts.enabled.insert("acct-claude-work".into());
    w.accounts.role_preferred.insert(
        ("reviewer".into(), Provider::Anthropic),
        "acct-claude-work".into(),
    );
    w.keep_awake = true;
    v.push(w);

    let mut w = Workspace::new(2, "infra-control-plane", "/workspace/infra-control-plane");
    w.mounts = vec![
        Mount::host(
            "~/src/infra-control-plane",
            "/workspace/infra-control-plane",
        )
        .repository(),
    ];
    w.roles = RolePolicy {
        allowed: AllowedRoles::All,
        default: Some("sre".into()),
        last: Some("sre".into()),
    };
    w.env = vec![
        EnvVar::op(
            "CLOUDFLARE_API_TOKEN",
            op_ref(
                "chainargos.1password.com",
                ("v_eng01", "Engineering"),
                ("it_cf01", "Cloudflare · infra"),
                "credential",
            ),
        ),
        EnvVar::plain("TF_LOG", "WARN"),
    ];
    // the inherited Codex default is switched off here; Experiments is
    // enabled and therefore the only (and preferred) Codex account
    w.accounts
        .disabled_defaults
        .insert("acct-codex-primary".into());
    w.accounts.enabled.insert("acct-codex-experiments".into());
    w.accounts
        .preferred
        .insert(Provider::OpenAi, "acct-codex-experiments".into());
    v.push(w);

    let mut w = Workspace::new(3, "release-automation", "/workspace/release-automation");
    w.mounts = vec![Mount::git(
        "github.com/chainargos/release-automation",
        "/workspace/release-automation",
    )];
    w.roles = RolePolicy {
        allowed: AllowedRoles::Custom(vec!["backend".into()]),
        default: Some("backend".into()),
        last: None,
    };
    w.git_pull = false;
    v.push(w);

    let mut w = Workspace::new(4, "customer-portal", "/workspace/customer-portal");
    w.mounts = vec![
        Mount::host("~/src/customer-portal", "/workspace/customer-portal").repository(),
        Mount::host("~/design/portal-assets", "/workspace/assets").readonly(true),
    ];
    w.roles = RolePolicy {
        allowed: AllowedRoles::All,
        default: None,
        last: Some("writer".into()),
    };
    w.env = vec![EnvVar::plain("NEXT_PUBLIC_API", "https://api.portal.local")];
    v.push(w);

    if rich {
        let names = [
            "data-pipeline",
            "docs-site",
            "auth-service",
            "gateway",
            "mobile-app",
            "ml-notebooks",
            "search-indexer",
            "staging-env",
            "billing-reconciliation-service-with-a-very-long-name-for-truncation",
            "legacy-monolith",
        ];
        for (i, n) in names.iter().enumerate() {
            let mut w = Workspace::new(10 + i as u32, n, &format!("/workspace/{n}"));
            let src = if i == 8 {
                "~/src/enterprise/platform/services/billing/reconciliation/billing-reconciliation-service-with-a-very-long-name-for-truncation".to_owned()
            } else {
                format!("~/src/{n}")
            };
            w.mounts = vec![Mount::host(&src, &format!("/workspace/{n}")).repository()];
            v.push(w);
        }
    }
    v
}

#[expect(
    clippy::too_many_arguments,
    reason = "fixture instance mirrors the full workspace record"
)]
fn instance(
    id: &str,
    ws: Option<u32>,
    wsname: &str,
    role: &str,
    agent: Agent,
    status: InstanceStatus,
    created: i64,
    last_seen: i64,
) -> Instance {
    Instance {
        id: id.into(),
        container: format!("jackin-{wsname}"),
        workspace: ws,
        workdir: format!("/workspace/{wsname}"),
        role: role.into(),
        agent,
        status,
        created_secs: created,
        last_seen_secs: last_seen,
        run_id: RunId::from_label(&format!("run-{}", &id[3..])),
        sessions: Ok(vec![]),
        daemon: DaemonSnapshot::Unavailable,
        branch: None,
        pr: None,
        default_branch: "main".into(),
        uncommitted: 0,
        unpushed: 0,
        accounts: vec![],
    }
}

fn accounts_mixed(now: i64) -> AccountRegistry {
    let h = 3600;
    let d = 86_400;
    let mut r = AccountRegistry::default();

    let mut a = Account::registered(
        "acct-claude-personal",
        "Personal",
        Provider::Anthropic,
        CredentialSource::LocalFolder {
            path: "~/.claude".into(),
            detected: DetectedKind::ClaudeOAuthProfile,
        },
    );
    a.identity = AccountIdentity {
        subject: handle("alexey@donbeave.dev"),
        plan: Some("Max 5x".into()),
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Available;
    a.purpose = Some("personal".into());
    a.default_for_provider = true;
    a.validation = ValidationState::Valid(ValidationLevel::QuotaReadable);
    a.last_refresh_secs = Some(now - 4 * 60);
    a.usage = AccountUsage {
        freshness: FreshnessInfo::current(now - 4 * 60),
        windows: vec![
            QuotaWindow::pct("session", "Session · 5-hour", WindowCategory::Session, 38)
                .reset(now + 3 * h + 12 * 60),
            QuotaWindow::pct(
                "weekly",
                "Weekly · all models",
                WindowCategory::LongRange,
                33,
            )
            .reset(now + 3 * d + 10 * h),
            QuotaWindow::pct(
                "weekly_sonnet",
                "Weekly · Sonnet",
                WindowCategory::Model,
                21,
            )
            .reset(now + 3 * d + 10 * h),
            QuotaWindow::pct("weekly_opus", "Weekly · Opus", WindowCategory::Model, 54)
                .reset(now + 3 * d + 10 * h),
        ],
    };
    r.insert(a);

    let mut a = Account::registered(
        "acct-claude-work",
        "Work",
        Provider::Anthropic,
        CredentialSource::OnePassword(op_ref(
            "chainargos.1password.com",
            ("v_eng01", "Engineering"),
            ("it_ant01", "Anthropic · Work"),
            "credential",
        )),
    );
    a.identity = AccountIdentity {
        subject: handle("alexey@chainargos.com"),
        plan: Some("Team".into()),
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Available;
    a.purpose = Some("work".into());
    a.validation = ValidationState::Valid(ValidationLevel::QuotaReadable);
    a.last_refresh_secs = Some(now - 47 * 60);
    a.issue = Some(
        RecoverableIssue::new(
            IssueCode::Stale,
            "Usage stale · last good 47 min ago",
            Recoverability::Retryable,
        )
        .retry(now + 13 * 60),
    );
    a.usage = AccountUsage {
        freshness: FreshnessInfo::stale(now - 47 * 60, now + 13 * 60),
        windows: vec![
            QuotaWindow::pct("session", "Session · 5-hour", WindowCategory::Session, 76)
                .reset(now + h + 5 * 60),
            QuotaWindow::pct(
                "weekly",
                "Weekly · all models",
                WindowCategory::LongRange,
                88,
            )
            .reset(now + 3 * d + 10 * h),
            QuotaWindow::pct("weekly_opus", "Weekly · Opus", WindowCategory::Model, 100)
                .reset(now + 3 * d + 10 * h),
            QuotaWindow::counted(
                "credits",
                "Extra usage credits",
                WindowCategory::Other,
                WindowUnit::Usd,
                1_420,
                5_000,
            )
            .spend("$14.20 of $50.00"),
        ],
    };
    r.insert(a);

    let mut a = Account::registered(
        "acct-codex-primary",
        "Primary",
        Provider::OpenAi,
        CredentialSource::OnePassword(op_ref(
            "chainargos.1password.com",
            ("v_eng01", "Engineering"),
            ("it_cdx01", "OpenAI · Codex Primary"),
            "credential",
        )),
    );
    a.identity = AccountIdentity {
        subject: handle("ChatGPT account org_7Hq2"),
        plan: Some("Pro 20x".into()),
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Available;
    a.purpose = Some("work".into());
    a.default_for_provider = true;
    a.validation = ValidationState::Valid(ValidationLevel::QuotaReadable);
    a.last_refresh_secs = Some(now - 2 * 60);
    a.usage = AccountUsage {
        freshness: FreshnessInfo::current(now - 2 * 60),
        windows: vec![
            QuotaWindow::pct("session", "Session · 5-hour", WindowCategory::Session, 12)
                .reset(now + 4 * h + 40 * 60),
            QuotaWindow::pct("weekly", "Weekly · 7-day", WindowCategory::LongRange, 59)
                .reset(now + 2 * d + 19 * h),
            QuotaWindow::not_started("spark", "Codex Spark · 5-hour", WindowCategory::Model),
            QuotaWindow::counted(
                "credits",
                "Credits",
                WindowCategory::Other,
                WindowUnit::Credits,
                1_240,
                5_000,
            ),
        ],
    };
    r.insert(a);

    let mut a = Account::registered(
        "acct-codex-experiments",
        "Experiments",
        Provider::OpenAi,
        CredentialSource::PlainApiKey {
            fingerprint: "7f3a91c2".into(),
            tail: "k7Qz".into(),
        },
    );
    a.identity = AccountIdentity {
        subject: handle("ChatGPT account org_7Hq2"),
        plan: Some("Plus".into()),
    };
    a.confidence = Confidence::Estimated;
    a.lifecycle = Lifecycle::Available;
    a.purpose = Some("experiments".into());
    a.validation = ValidationState::Valid(ValidationLevel::IdentityAuthenticated);
    a.last_refresh_secs = Some(now - 20 * 60);
    a.issue = Some(RecoverableIssue::new(
        IssueCode::QuotaUnsupported,
        "Quota not visible: OpenAI does not expose usage for API keys",
        Recoverability::Unsupported,
    ));
    a.usage = AccountUsage {
        freshness: FreshnessInfo::refreshing(Some(now - 20 * 60)),
        windows: vec![
            QuotaWindow::pct("session", "Session · 5-hour", WindowCategory::Session, 4)
                .reset(now + 4 * h),
            QuotaWindow::pct("weekly", "Weekly · 7-day", WindowCategory::LongRange, 12)
                .reset(now + 2 * d + 19 * h),
            QuotaWindow::counted(
                "credits",
                "Credits",
                WindowCategory::Other,
                WindowUnit::Credits,
                90,
                500,
            ),
            QuotaWindow::sentinel(
                "quota",
                "Quota",
                QuotaStatus::Unsupported,
                "Quota not visible for API keys",
            ),
        ],
    };
    r.insert(a);

    let mut a = Account::registered(
        "acct-grok-team",
        "Team",
        Provider::XAi,
        CredentialSource::OnePassword(op_ref(
            "chainargos.1password.com",
            ("v_eng01", "Engineering"),
            ("it_grk01", "xAI · Grok Team"),
            "credential",
        )),
    )
    .with_endpoint("Grok Build (default)", "api.x.ai");
    a.identity = AccountIdentity {
        subject: handle("team_chainargos"),
        plan: Some("Team · prepaid".into()),
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Available;
    a.purpose = Some("shared".into());
    a.default_for_provider = true;
    a.validation = ValidationState::Valid(ValidationLevel::QuotaReadable);
    a.last_refresh_secs = Some(now - 9 * 60);
    a.usage = AccountUsage {
        freshness: FreshnessInfo::current(now - 9 * 60),
        windows: vec![
            QuotaWindow::pct("monthly", "Monthly", WindowCategory::LongRange, 31)
                .reset(now + 27 * d + 10 * h),
            QuotaWindow::pct("weekly", "Weekly", WindowCategory::LongRange, 68)
                .reset(now + 3 * d + 10 * h),
            QuotaWindow::counted(
                "credits",
                "Credits",
                WindowCategory::Other,
                WindowUnit::Usd,
                3_140,
                10_000,
            )
            .spend("$68.60 remaining of $100.00"),
            QuotaWindow::counted(
                "ondemand",
                "On-demand usage",
                WindowCategory::Other,
                WindowUnit::Usd,
                315,
                315,
            )
            .status(QuotaStatus::Available)
            .spend("$3.15 this month"),
        ],
    };
    r.insert(a);

    let mut a = Account::registered(
        "acct-opencode-go",
        "Go subscription",
        Provider::OpenCode,
        CredentialSource::PlainApiKey {
            fingerprint: "c41d0be9".into(),
            tail: "m2Xa".into(),
        },
    );
    a.identity = AccountIdentity {
        subject: handle("donbeave"),
        plan: Some("OpenCode Go".into()),
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Available;
    a.default_for_provider = true;
    a.validation = ValidationState::Valid(ValidationLevel::IdentityAuthenticated);
    a.last_refresh_secs = Some(now - 3 * h - 2 * 60);
    a.issue = Some(
        RecoverableIssue::new(
            IssueCode::RateLimited,
            "Rate limited: retry after 25 min",
            Recoverability::Retryable,
        )
        .detail("Last-good data kept from 3 h ago")
        .retry(now + 25 * 60),
    );
    a.usage = AccountUsage {
        freshness: FreshnessInfo::failed(Some(now - 3 * h - 2 * 60), Some(now + 25 * 60)),
        windows: vec![
            QuotaWindow::pct("rolling", "Rolling", WindowCategory::Session, 57)
                .reset(now + h + 50 * 60),
            QuotaWindow::pct("weekly", "Weekly", WindowCategory::LongRange, 45).reset(now + 3 * d),
            QuotaWindow::pct("monthly", "Monthly", WindowCategory::LongRange, 22)
                .reset(now + 27 * d),
        ],
    };
    r.insert(a);

    let mut a = Account::registered(
        "acct-claude-archive",
        "Archived contractor laptop profile — do not use for production launches",
        Provider::Anthropic,
        CredentialSource::LocalFolder {
            path: "~/Library/Application Support/jackin/profiles/claude-contractor-2025-archive"
                .into(),
            detected: DetectedKind::ClaudeApiKeyEnv,
        },
    );
    a.confidence = Confidence::PresenceOnly;
    a.lifecycle = Lifecycle::NeedsLogin;
    a.enabled = false;
    a.validation = ValidationState::Valid(ValidationLevel::MaterialDiscovered);
    a.last_refresh_secs = Some(now - 30 * d);
    a.issue = Some(RecoverableIssue::new(
        IssueCode::IdentityUnresolved,
        "Identity unresolved · showing usage without a public handle",
        Recoverability::Unsupported,
    ));
    a.usage = AccountUsage {
        freshness: FreshnessInfo::current(now - 30 * d),
        windows: vec![],
    };
    r.insert(a);

    // discovered, read-only
    let mut a = Account::discovered(
        "disc-amp",
        "discovered",
        Provider::Amp,
        CredentialSource::LocalFolder {
            path: "~/.config/amp/secrets.json".into(),
            detected: DetectedKind::AmpSecrets,
        },
    );
    a.identity = AccountIdentity {
        subject: None,
        plan: Some("Free".into()),
    };
    a.confidence = Confidence::PresenceOnly;
    a.lifecycle = Lifecycle::Available;
    a.validation = ValidationState::Valid(ValidationLevel::QuotaReadable);
    a.last_refresh_secs = Some(now - 60);
    a.usage = AccountUsage {
        freshness: FreshnessInfo::current(now - 60),
        windows: vec![
            QuotaWindow::pct(
                "daily_free",
                "Amp Free · daily",
                WindowCategory::Session,
                91,
            )
            .reset(now + 10 * h),
            QuotaWindow::counted(
                "credits",
                "Individual credits",
                WindowCategory::Other,
                WindowUnit::Usd,
                0,
                0,
            )
            .spend("$0.00"),
        ],
    };
    r.insert(a);

    let mut a = Account::discovered(
        "disc-zai",
        "discovered",
        Provider::Zai,
        CredentialSource::HostEnv {
            var: "ZAI_API_KEY".into(),
            detected: DetectedKind::ZaiApiKeyEnv,
        },
    );
    a.identity = AccountIdentity {
        subject: handle("zai_9f1c"),
        plan: Some("GLM Coding Plan Pro".into()),
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Available;
    a.validation = ValidationState::Valid(ValidationLevel::QuotaReadable);
    a.last_refresh_secs = Some(now - 2 * h - 15 * 60);
    a.issue = Some(RecoverableIssue::new(
        IssueCode::Stale,
        "Usage stale · last good 2 h ago",
        Recoverability::Retryable,
    ));
    a.usage = AccountUsage {
        freshness: FreshnessInfo::stale(now - 2 * h - 15 * 60, now + 10 * 60),
        windows: vec![
            QuotaWindow::counted(
                "session",
                "Session",
                WindowCategory::Session,
                WindowUnit::Tokens,
                4_200_000,
                10_000_000,
            )
            .reset(now + 2 * h),
            QuotaWindow::counted(
                "weekly",
                "Weekly",
                WindowCategory::LongRange,
                WindowUnit::Tokens,
                61_000_000,
                80_000_000,
            )
            .reset(now + 4 * d),
            QuotaWindow::counted(
                "credits",
                "Credits",
                WindowCategory::Other,
                WindowUnit::Credits,
                310,
                1_000,
            ),
        ],
    };
    r.insert(a);

    let mut a = Account::discovered(
        "disc-kimi",
        "discovered",
        Provider::Moonshot,
        CredentialSource::LocalFolder {
            path: "~/.kimi".into(),
            detected: DetectedKind::KimiApiKeyEnv,
        },
    );
    a.identity = AccountIdentity {
        subject: None,
        plan: Some("Kimi Code".into()),
    };
    a.confidence = Confidence::PresenceOnly;
    a.lifecycle = Lifecycle::NeedsSecret;
    a.validation = ValidationState::Valid(ValidationLevel::MaterialDiscovered);
    a.issue = Some(RecoverableIssue::new(
        IssueCode::CredentialFileMissing,
        "No credential found: ~/.kimi has no api key",
        Recoverability::ActionRequired,
    ));
    a.usage = AccountUsage {
        freshness: FreshnessInfo::failed(None, None),
        windows: vec![QuotaWindow::sentinel(
            "quota",
            "Quota",
            QuotaStatus::Unavailable,
            "Quota unavailable until a key is present",
        )],
    };
    r.insert(a);

    let mut a = Account::discovered(
        "disc-minimax",
        "discovered",
        Provider::MiniMax,
        CredentialSource::HostEnv {
            var: "MINIMAX_API_TOKEN".into(),
            detected: DetectedKind::MinimaxTokenEnv,
        },
    );
    a.identity = AccountIdentity {
        subject: handle("mm_4471"),
        plan: Some("Coding Plan".into()),
    };
    a.confidence = Confidence::Estimated;
    a.lifecycle = Lifecycle::Unavailable;
    a.validation = ValidationState::Valid(ValidationLevel::IdentityAuthenticated);
    a.last_refresh_secs = Some(now - 6 * h);
    a.issue = Some(
        RecoverableIssue::new(
            IssueCode::ProviderUnavailable,
            "Provider unavailable: MiniMax did not respond",
            Recoverability::Retryable,
        )
        .detail("Timed out after 8 s"),
    );
    a.usage = AccountUsage {
        freshness: FreshnessInfo::failed(Some(now - 6 * h), Some(now + 15 * 60)),
        windows: vec![
            QuotaWindow::pct(
                "general_session",
                "General · Session",
                WindowCategory::Session,
                8,
            )
            .reset(now + 3 * h),
            QuotaWindow::pct(
                "general_weekly",
                "General · Weekly",
                WindowCategory::LongRange,
                34,
            )
            .reset(now + 5 * d),
            QuotaWindow::pct(
                "m2_weekly",
                "MiniMax-M2 · Weekly",
                WindowCategory::Model,
                47,
            )
            .reset(now + 5 * d),
        ],
    };
    r.insert(a);

    let mut a = Account::discovered(
        "disc-opencode-ci",
        "ci-bot",
        Provider::OpenCode,
        CredentialSource::LocalFolder {
            path: "~/.local/share/opencode/auth.json".into(),
            detected: DetectedKind::OpenCodeGoAuthJson,
        },
    );
    a.identity = AccountIdentity {
        subject: handle("ci-bot"),
        plan: None,
    };
    a.confidence = Confidence::Authoritative;
    a.lifecycle = Lifecycle::Unsupported;
    a.validation = ValidationState::Valid(ValidationLevel::IdentityAuthenticated);
    a.last_refresh_secs = Some(now - 5 * 60);
    a.issue = Some(RecoverableIssue::new(
        IssueCode::QuotaUnsupported,
        "Quota not visible: OpenCode returned 403",
        Recoverability::Unsupported,
    ));
    a.usage = AccountUsage {
        freshness: FreshnessInfo::current(now - 5 * 60),
        windows: vec![QuotaWindow::sentinel(
            "quota",
            "Quota",
            QuotaStatus::Unsupported,
            "Quota not visible: OpenCode returned 403",
        )],
    };
    r.insert(a);
    r
}

fn accounts_hard(now: i64) -> AccountRegistry {
    let mut r = accounts_mixed(now);
    let mut a = Account::registered(
        "acct-grok-revoked",
        "Revoked key",
        Provider::XAi,
        CredentialSource::OnePassword(op_ref(
            "chainargos.1password.com",
            ("v_eng01", "Engineering"),
            ("it_leg01", "Legacy · Rotated key"),
            "credential",
        )),
    );
    a.lifecycle = Lifecycle::NeedsLogin;
    a.validation = ValidationState::Invalid(RecoverableIssue::new(
        IssueCode::Unauthorized,
        "Not authorized: xAI rejected the credential",
        Recoverability::ActionRequired,
    ));
    a.issue = Some(
        RecoverableIssue::new(
            IssueCode::Unauthorized,
            "Not authorized: xAI rejected the credential",
            Recoverability::ActionRequired,
        )
        .detail("HTTP 401 · re-login required"),
    );
    a.last_refresh_secs = Some(now - 40 * 60);
    a.usage = AccountUsage {
        freshness: FreshnessInfo::failed(None, None),
        windows: vec![],
    };
    r.insert(a);
    // long labels
    if let Some(w) = r.get_mut("acct-claude-work")
        && let Some(win) = w.usage.windows.iter_mut().find(|w| w.id == "weekly")
    {
        win.label =
            "Weekly · all models · includes Claude Code, desktop and API usage on the Team plan"
                .into();
    }
    r
}

pub(crate) fn populate(w: &mut World, rich: bool) {
    let now = w.now_secs();
    let h = 3600;
    let d = 86_400;
    w.workspaces = workspaces_for(w.scenario);
    w.accounts = if rich {
        accounts_hard(now)
    } else {
        accounts_mixed(now)
    };
    // instances
    let mut i1 = instance(
        "jk-7f3a",
        Some(1),
        "payments-platform",
        "the-architect",
        Agent::ClaudeCode,
        InstanceStatus::Running,
        now - 2 * h - 14 * 60,
        now - 3,
    );
    i1.branch = Some("feature/settlement-backoff".into());
    i1.pr = Some((482, "Settlement retry backoff".into()));
    i1.uncommitted = 2;
    i1.unpushed = 1;
    i1.sessions = Ok(vec![
        SessionRecord {
            id: "s-01".into(),
            agent: Some(Agent::ClaudeCode),
            label: "claude · the-architect".into(),
            status: SessionStatus::Active,
            started_secs: now - 2 * h - 14 * 60,
        },
        SessionRecord {
            id: "s-02".into(),
            agent: Some(Agent::Codex),
            label: "codex · ledger tests".into(),
            status: SessionStatus::Exited(0),
            started_secs: now - d,
        },
    ]);
    let mut i2 = instance(
        "jk-c41e",
        Some(1),
        "payments-platform",
        "reviewer",
        Agent::Codex,
        InstanceStatus::PreservedDirty,
        now - d - 3 * h,
        now - d,
    );
    i2.uncommitted = 3;
    i2.sessions = Ok(vec![SessionRecord {
        id: "s-03".into(),
        agent: Some(Agent::Codex),
        label: "codex · review".into(),
        status: SessionStatus::Exited(0),
        started_secs: now - d - 3 * h,
    }]);
    let mut i3 = instance(
        "jk-9b02",
        Some(2),
        "infra-control-plane",
        "sre",
        Agent::Codex,
        InstanceStatus::Running,
        now - 40 * 60,
        now - 2,
    );
    i3.branch = Some("sre/node-pools".into());
    i3.sessions = Ok(vec![SessionRecord {
        id: "s-04".into(),
        agent: Some(Agent::Codex),
        label: "codex · sre".into(),
        status: SessionStatus::Active,
        started_secs: now - 40 * 60,
    }]);
    let mut i4 = instance(
        "jk-12ee",
        Some(4),
        "customer-portal",
        "writer",
        Agent::Amp,
        InstanceStatus::Crashed,
        now - 5 * h,
        now - 4 * h,
    );
    i4.sessions = Ok(vec![SessionRecord {
        id: "s-05".into(),
        agent: Some(Agent::Amp),
        label: "amp · docs".into(),
        status: SessionStatus::Crashed,
        started_secs: now - 5 * h,
    }]);
    let i5 = instance(
        "jk-a1c0",
        Some(3),
        "release-automation",
        "backend",
        Agent::OpenCode,
        InstanceStatus::RestoreAvailable,
        now - 3 * d,
        now - 3 * d,
    );
    let mut i6 = instance(
        "jk-04d7",
        Some(2),
        "infra-control-plane",
        "sre",
        Agent::GrokBuild,
        InstanceStatus::PreservedUnpushed,
        now - 2 * d,
        now - 2 * d,
    );
    i6.unpushed = 2;
    let i7 = instance(
        "jk-77aa",
        Some(1),
        "payments-platform",
        "backend",
        Agent::Codex,
        InstanceStatus::Superseded,
        now - 6 * d,
        now - 6 * d,
    );
    let i8 = instance(
        "jk-88bb",
        Some(4),
        "customer-portal",
        "writer",
        Agent::KimiCode,
        InstanceStatus::Purged,
        now - 9 * d,
        now - 9 * d,
    );
    let mut i9 = instance(
        "jk-5e5e",
        Some(3),
        "release-automation",
        "backend",
        Agent::Codex,
        InstanceStatus::FailedSetup,
        now - 30 * 60,
        now - 30 * 60,
    );
    i9.sessions = Ok(vec![]);
    w.instances = vec![i1, i2, i3, i4, i5, i6, i7, i8, i9];
    if rich {
        // many instances, missing daemon data, manifest error
        let mut i10 = instance(
            "jk-e0e0",
            Some(10),
            "data-pipeline",
            "backend",
            Agent::ClaudeCode,
            InstanceStatus::Running,
            now - 10 * 60,
            now - 90,
        );
        i10.sessions = Err(ManifestError::ReadError);
        w.instances.push(i10);
        let i11 = instance(
            "jk-f1f1",
            Some(11),
            "docs-site",
            "writer",
            Agent::KimiCode,
            InstanceStatus::CleanExited,
            now - 4 * d,
            now - 4 * d,
        );
        w.instances.push(i11);
        for k in 0..6 {
            let id = format!("jk-b{k}{k}{k}");
            let st = if k % 2 == 0 {
                InstanceStatus::CleanExited
            } else {
                InstanceStatus::RestoreAvailable
            };
            w.instances.push(instance(
                &id,
                Some(1),
                "payments-platform",
                "reviewer",
                Agent::Codex,
                st,
                now - (k + 2) * d,
                now - (k + 2) * d,
            ));
        }
    }
    // daemons for running instances
    let now_ms = w.now_ms();
    let mut d1 = Daemon::new("payments-platform");
    d1.new_tab(
        Some(Agent::ClaudeCode),
        Some("acct-claude-work".into()),
        now_ms - 60_000,
        true,
    );
    d1.split(
        SplitDir::Horizontal,
        false,
        Some(Agent::Codex),
        Some("acct-codex-primary".into()),
        now_ms - 50_000,
        true,
    );
    d1.split(SplitDir::Vertical, false, None, None, now_ms - 40_000, true);
    if let Some(t) = d1.active_tab_mut() {
        t.focused = 1;
    }
    d1.new_tab(None, None, now_ms - 30_000, true);
    d1.new_tab(Some(Agent::Amp), None, now_ms - 20_000, true);
    if let Some(t) = d1.tabs.get_mut(2) {
        t.custom_label = Some("docs".into());
    }
    d1.active = 0;
    // long shell log for scrollback
    if let Some(p) = d1.pane_mut(3) {
        for n in 0..1_960u32 {
            let status = match n % 7 {
                0 => "retrying attempt=2",
                3 => "retrying attempt=1",
                _ => "settled",
            };
            let items = 9 + (n * 37) % 50;
            let l = if n % 60 == 0 {
                vec![Span::new(
                    format!(
                        "==== settlement.batch.2026-09-03T{:02}:{:02}Z ====",
                        9 + n / 360,
                        (n / 6) % 60
                    ),
                    Tone::Muted,
                )]
            } else if n % 23 == 0 {
                vec![Span::new(
                    format!("warn: batch {} backoff 500 ms", 4000 + n),
                    Tone::Warning,
                )]
            } else if n % 97 == 0 {
                vec![Span::new(
                    format!("error: batch {} gave up after 3 attempts", 4000 + n),
                    Tone::Error,
                )]
            } else {
                vec![Span::new(
                    format!("batch {}  {:>2} items   status={status}", 4000 + n, items),
                    Tone::Normal,
                )]
            };
            p.term.lines.insert(0, l);
        }
        let lines = std::mem::take(&mut p.term.lines);
        p.term = TextViewport::new();
        for line in lines {
            p.term.push(line);
        }
    }
    w.daemons.insert("jk-7f3a".into(), d1);
    let mut d3 = Daemon::new("infra-control-plane");
    d3.new_tab(
        Some(Agent::Codex),
        Some("acct-codex-experiments".into()),
        now_ms - 30_000,
        true,
    );
    w.daemons.insert("jk-9b02".into(), d3);
    if rich {
        let d10 = Daemon::new("data-pipeline");
        w.daemons.insert("jk-e0e0".into(), d10);
        // its daemon never answers
        if let Some(i) = w.instance_mut("jk-e0e0") {
            i.daemon = DaemonSnapshot::Unavailable;
        }
        w.daemons.remove("jk-e0e0");
    }
    // every instance carries the effective account set of its Workspace
    let registry = w.accounts.clone();
    let sets: Vec<(u32, Vec<AccountId>)> = w
        .workspaces
        .iter()
        .map(|ws| {
            (
                ws.id,
                ws.effective_accounts(&registry)
                    .into_iter()
                    .map(|e| e.id)
                    .collect(),
            )
        })
        .collect();
    for i in w.instances.iter_mut() {
        if let Some((_, set)) = i
            .workspace
            .and_then(|id| sets.iter().find(|(w, _)| *w == id))
        {
            i.accounts = set.clone();
        }
    }
    canonicalize_roles(w);
    refresh_snapshots(w);
    w.sync_arbiter();
}

pub(crate) fn refresh_snapshots(w: &mut World) {
    let snaps: Vec<(String, DaemonSnapshot)> = w
        .daemons
        .iter()
        .map(|(id, d)| (id.clone(), d.snapshot()))
        .collect();
    for (id, s) in snaps {
        if let Some(i) = w.instance_mut(&id) {
            i.daemon = s;
        }
    }
    for i in w.instances.iter_mut() {
        if i.status != InstanceStatus::Running {
            i.daemon = DaemonSnapshot::Unavailable;
        }
    }
}

// Exact source catalog identities; no label parsing or generic namespace stripping.
fn canonical_role(short: &str) -> &str {
    match short {
        "the-architect" => "chainargos/the-architect",
        "backend" => "chainargos/backend",
        "reviewer" => "chainargos/reviewer",
        "sre" => "chainargos/sre",
        "writer" => "local/writer",
        _ => short,
    }
}

fn canonicalize_workspace_roles(workspaces: &mut [Workspace]) {
    for ws in workspaces {
        if let AllowedRoles::Custom(roles) = &mut ws.roles.allowed {
            for role in roles {
                *role = canonical_role(role).to_owned();
            }
        }
        for role in [&mut ws.roles.default, &mut ws.roles.last]
            .into_iter()
            .flatten()
        {
            *role = canonical_role(role).to_owned();
        }
        ws.role_env = std::mem::take(&mut ws.role_env)
            .into_iter()
            .map(|(role, env)| (canonical_role(&role).to_owned(), env))
            .collect();
        ws.accounts.role_preferred = std::mem::take(&mut ws.accounts.role_preferred)
            .into_iter()
            .map(|((role, provider), account)| {
                ((canonical_role(&role).to_owned(), provider), account)
            })
            .collect();
    }
}

fn canonicalize_roles(w: &mut World) {
    for instance in &mut w.instances {
        instance.role = canonical_role(&instance.role).to_owned();
    }
}

pub(crate) fn roles_for(scenario: Scenario) -> Vec<RoleEntry> {
    let mut result = roles();
    if scenario != Scenario::FirstUse {
        result.extend(generated_roles(if scenario == Scenario::HardCases {
            120
        } else {
            40
        }));
    }
    result
}

pub(crate) fn workspaces_for(scenario: Scenario) -> Vec<Workspace> {
    if scenario == Scenario::FirstUse {
        return Vec::new();
    }
    let mut result = workspaces(scenario == Scenario::HardCases);
    canonicalize_workspace_roles(&mut result);
    result
}

// Source794b095 fixtures649–691, copied as public metadata only.
pub(crate) fn github() -> Vec<GithubRepo> {
    let r = |n: &str, b: &str, extra: &[&str], upd: &str| GithubRepo {
        full_name: n.into(),
        default_branch: b.into(),
        branches: std::iter::once(b.to_owned())
            .chain(extra.iter().map(|s| (*s).to_owned()))
            .collect(),
        updated: upd.into(),
        url: format!("https://github.com/{n}"),
    };
    vec![
        r(
            "chainargos/payments-platform",
            "main",
            &["feature/settlement-backoff", "release/2026.09"],
            "1 h ago",
        ),
        r(
            "chainargos/infra-control-plane",
            "main",
            &["sre/node-pools"],
            "3 h ago",
        ),
        r(
            "chainargos/release-automation",
            "main",
            &["node-22"],
            "2 d ago",
        ),
        r(
            "chainargos/customer-portal",
            "develop",
            &["main", "feature/skeletons"],
            "5 h ago",
        ),
        r("chainargos/roles", "main", &[], "6 d ago"),
        r("chainargos/docs", "main", &["gh-pages"], "3 d ago"),
        r("acme-labs/roles-experimental", "next", &[], "2 mo ago"),
    ]
}
