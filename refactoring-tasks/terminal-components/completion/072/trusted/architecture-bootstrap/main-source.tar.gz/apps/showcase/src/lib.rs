//! The public component showcase application.
//!
//! The binary is intentionally a thin wrapper. Keeping the application in a
//! library gives integration tests the same public entry point as downstream
//! consumers and makes the `junie-tui` facade boundary compiler-enforced.

#![expect(
    clippy::arithmetic_side_effects,
    clippy::collapsible_if,
    clippy::too_many_lines,
    reason = "historical compatibility pages keep bounded fixture arithmetic and composition together"
)]

mod app;
mod data;
mod pages;
mod render_number;

pub use app::{App, NAV_ENTRIES, NavEntry, PageId};

/// Run the showcase with command-line theme and colour selection.
///
/// # Errors
///
/// Returns terminal setup or teardown errors from the `junie-tui` runtime.
pub fn run() -> std::io::Result<()> {
    app::run()
}
