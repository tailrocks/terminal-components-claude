//! Focused performance smoke tests for the migrated app.
use std::hint::black_box;

use junie_tui::{Axis, KeyCode, Theme};
use junie_tui_testing::{Harness, perf};
use showcase_app::{App, PageId};

#[global_allocator]
static GLOBAL: perf::Counting = perf::Counting;

#[expect(
    clippy::panic,
    reason = "a missing benchmark target is a real test failure, never a skipped run"
)]
fn require<T>(value: Option<T>, message: &str) -> T {
    match value {
        Some(value) => value,
        None => panic!("{message}"),
    }
}

fn app(page: PageId, width: u16, height: u16) -> Harness<App> {
    Harness::new(App::with_page(page), Theme::junie(), width, height)
}

#[test]
fn frame_showcase_lists_120x40() {
    let mut h = app(PageId::Lists, 120, 40);
    let first = h.snapshot().digest();
    for _ in 0..200 {
        h.draw();
    }
    let last = h.snapshot().digest();
    assert_eq!(
        first, last,
        "steady-state list frames must be deterministic"
    );
    black_box(last);
}

#[test]
fn frame_showcase_lists_80x24() {
    let mut h = app(PageId::Lists, 80, 24);
    let first = h.snapshot().digest();
    for _ in 0..200 {
        h.draw();
    }
    let last = h.snapshot().digest();
    assert_eq!(first, last, "compact list frames must be deterministic");
    black_box(last);
}

#[test]
fn frame_showcase_dialog_open() {
    let mut h = app(PageId::Dialogs, 120, 40);
    let _ = h.key(KeyCode::Char('?'));
    assert!(h.text().contains("Keyboard & mouse"));
    // Opening a layer settles its focus scope on the next draw; benchmark the
    // steady-state frame rather than the hand-off frame.
    h.draw();
    let first = h.snapshot().digest();
    for _ in 0..200 {
        h.draw();
    }
    let last = h.snapshot().digest();
    assert_eq!(first, last, "open dialog frames must be deterministic");
    black_box(last);
}

#[test]
fn key_showcase_down_lists() {
    let mut h = app(PageId::Lists, 120, 40);
    let _ = h.key(KeyCode::Tab);
    for _ in 0..1_000 {
        let _ = h.key(KeyCode::Down);
    }
    assert!(h.text().contains("Lists"));
    black_box(h.snapshot().digest());
}

#[test]
fn mouse_move_showcase_frame() {
    let mut h = app(PageId::Overview, 120, 40);
    let mut hovered = 0_u32;
    for y in 0..40 {
        for x in (0..120).step_by(2) {
            let _ = h.mouse(junie_tui::MouseKind::Move, x, y);
            if h.hover().is_some() {
                hovered = hovered.saturating_add(1);
            }
        }
    }
    assert!(hovered > 0, "pointer sweep must hit registered regions");
    black_box(h.snapshot().digest());
}

#[test]
fn wheel_showcase_lists() {
    let mut h = app(PageId::Lists, 80, 24);
    let (summary_x, summary_y) = require(h.find("Rust"), "chosen-language summary is visible");
    assert_eq!(summary_y, 6, "reference summary is outside the viewport");
    let first = h.snapshot().digest();
    let _ = h.wheel(Axis::V, 2, summary_x, summary_y);
    assert_eq!(
        first,
        h.snapshot().digest(),
        "summary must not capture wheel input"
    );
    // Holla's 80×24 fixture puts the first visible language at (26, 8).
    // Match its row prefix so the earlier summary cannot become the target.
    let (gutter_x, y) = require(h.find("▎› Rust"), "first language row is visible");
    assert_eq!((gutter_x, y), (23, 8));
    let x = gutter_x + 3;
    for _ in 0..1_000 {
        let _ = h.wheel(Axis::V, 2, x, y);
    }
    let last = h.snapshot().digest();
    assert_ne!(
        first, last,
        "wheel input must route through the list viewport"
    );
    black_box(last);
}

#[test]
fn render_twice_allocates_the_same() {
    let mut h = app(PageId::Overview, 120, 40);
    h.draw();
    let first = h.snapshot().digest();
    for _ in 0..200 {
        h.draw();
    }
    let second = h.snapshot().digest();
    assert_eq!(first, second, "repeated renders must keep the same scene");
}

#[test]
fn perf_showcase_baseline() {
    let _guard = perf::lock();
    let mut harness = app(PageId::Lists, 120, 40);
    let stats = perf::bench(2, perf::iters(200), &mut || {
        harness.draw();
        black_box(harness.focus());
    });
    perf::report_to(
        concat!(env!("CARGO_MANIFEST_DIR"), "/tests/perf_baseline.txt"),
        "frame_showcase_lists_120x40",
        &stats,
    );
}
