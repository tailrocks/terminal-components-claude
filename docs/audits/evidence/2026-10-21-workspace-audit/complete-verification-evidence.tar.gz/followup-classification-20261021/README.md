# PR #38 nextest failure reconciliation and source classification

- Commit: `52e1572caaf7d9effd0265bbfdf6edcd0e57533b`
- Source inspection was read-only; no tests rerun.
- Original evidence was preserved; original manifest SHA-256: `0a70fdf4a498b851976eaec7bad621a0ccae69a19715274ef6ba3509ef3f8a65`.

## Reconciliation

- Partition final FAIL lists contain 340 unique rows and agree with partition failed totals (50+47+44+43+40+41+42+33). The earlier extracted `failed-tests.txt` contains 334. All six omissions are ordinary FAIL rows, not other nextest status classes:

- `holla-ui::visual holla_visual_baseline`
- `jackin-preview-app app::paint_contract_tests::historical_failure_and_action_labels_remain_readable_in_mono`
- `showcase-ui::page_headings all_page_headings_match_the_reference_capture_matrix`
- `showcase-ui::page_headings all_shell_headers_match_reference_captures_and_visibility_thresholds`
- `termrock-conformance::conformance brand::local_override_does_not_mutate_the_theme`
- `termrock-conformance::conformance completion::local_override_does_not_mutate_the_theme`

Correct behavioral conformance count: **68** (not 66). Counts from the named logs:

- other shared component, app, perf, and documentation gates: **17**
- shared conformance contracts: **68**
- component render baseline snapshots: **232**
- visual capture/integrity/negative controls: **16**
- visual harness integrity/determinism/overlay: **4**
- control-state acceptance: **3**

## Classification cautions

- Component render snapshots are one shared renderer/theme contract surface; candidate-vs-baseline digest failure alone does not identify whether oracle or rendering is correct. Never bless from the candidate.
- Conformance failures include mutation/policy, mono state distinctions, bindings, focus/hover/traversal, and wheel consumption. Fix at shared component/update/input layer.
- The 20 visual baseline/harness-named failures mix verifier integrity/determinism issues with real negative-control behavior tests. Keep them distinct; the two behavior tests must not be dismissed as runner issues.
- Four app digest mismatches and two Showcase capture matrices are not a paired frozen-reference comparison. No exact parity conclusion is supported.

Detailed partition log hashes, classification, source paths, existing minimal repro locations, and proposed bounded workstreams are in `manifest.json`.
