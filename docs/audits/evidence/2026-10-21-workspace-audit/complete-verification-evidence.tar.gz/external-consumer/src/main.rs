use termrock::{App, Button, Cx, Id, Response, Ui, composition};

struct ExternalConsumer {
    import: Button<'static>,
    data_label: &'static str,
}

impl App for ExternalConsumer {
    fn update(&mut self, cx: &mut Cx<'_>) -> Response<()> {
        self.import.update(cx).erase()
    }

    fn draw(&self, ui: &mut Ui<'_>) {
        let _live_data = self.data_label;
        composition::Group::row([composition::button(&self.import)])
            .show(ui)
            .expect("external composition fits the public depth limit");
    }
}

fn main() {
    let _app = ExternalConsumer {
        import: Button::new(Id::root("external.import"), "Import 雪🚀"),
        data_label: "External package manifest · 17 modules",
    };
}
